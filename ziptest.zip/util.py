def greet(name):
    return f"hello {name}"
