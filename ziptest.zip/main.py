from util import greet
print(greet("zip"))
